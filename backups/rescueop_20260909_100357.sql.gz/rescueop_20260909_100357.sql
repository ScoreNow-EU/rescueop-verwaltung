--
-- PostgreSQL database dump
--

\restrict FrpdeujimlSi6fU2iSVqsQFqI8kNI56hVOXYmHzfE9VrSE6uqCFNoUvWdde94m3

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: my_vehicle; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.my_vehicle (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    my_wache_id integer NOT NULL,
    vehicle_type_id integer NOT NULL,
    nickname character varying(120)
);


ALTER TABLE public.my_vehicle OWNER TO rescueop;

--
-- Name: my_vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.my_vehicle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.my_vehicle_id_seq OWNER TO rescueop;

--
-- Name: my_vehicle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.my_vehicle_id_seq OWNED BY public.my_vehicle.id;


--
-- Name: my_vehicle_modules; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.my_vehicle_modules (
    my_vehicle_id integer NOT NULL,
    vehicle_module_id integer NOT NULL
);


ALTER TABLE public.my_vehicle_modules OWNER TO rescueop;

--
-- Name: my_wache; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.my_wache (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    name character varying(120) NOT NULL,
    wache_type_id integer NOT NULL,
    current_level integer NOT NULL,
    naming_org_type_id integer,
    naming_location_id integer
);


ALTER TABLE public.my_wache OWNER TO rescueop;

--
-- Name: my_wache_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.my_wache_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.my_wache_id_seq OWNER TO rescueop;

--
-- Name: my_wache_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.my_wache_id_seq OWNED BY public.my_wache.id;


--
-- Name: my_wache_upgrades; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.my_wache_upgrades (
    my_wache_id integer NOT NULL,
    wache_upgrade_id integer NOT NULL
);


ALTER TABLE public.my_wache_upgrades OWNER TO rescueop;

--
-- Name: naming_location; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.naming_location (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    abbreviation character varying(20) NOT NULL,
    full_name character varying(120) NOT NULL
);


ALTER TABLE public.naming_location OWNER TO rescueop;

--
-- Name: naming_location_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.naming_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.naming_location_id_seq OWNER TO rescueop;

--
-- Name: naming_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.naming_location_id_seq OWNED BY public.naming_location.id;


--
-- Name: naming_org_type; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.naming_org_type (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    abbreviation character varying(20) NOT NULL,
    full_name character varying(120) NOT NULL,
    no_location boolean NOT NULL,
    default_wache_type_id integer
);


ALTER TABLE public.naming_org_type OWNER TO rescueop;

--
-- Name: naming_org_type_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.naming_org_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.naming_org_type_id_seq OWNER TO rescueop;

--
-- Name: naming_org_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.naming_org_type_id_seq OWNED BY public.naming_org_type.id;


--
-- Name: naming_preset; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.naming_preset (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    name character varying(120) NOT NULL,
    template character varying(255) NOT NULL,
    description character varying(255),
    is_default boolean NOT NULL
);


ALTER TABLE public.naming_preset OWNER TO rescueop;

--
-- Name: naming_preset_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.naming_preset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.naming_preset_id_seq OWNER TO rescueop;

--
-- Name: naming_preset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.naming_preset_id_seq OWNED BY public.naming_preset.id;


--
-- Name: plan_item; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.plan_item (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    category character varying(30) NOT NULL,
    priority integer NOT NULL,
    done boolean NOT NULL,
    notes text,
    wache_name character varying(120),
    wache_type_id integer,
    wache_org_type_id integer,
    wache_location_id integer,
    created_wache_id integer,
    target_wache_id integer,
    target_wache_plan_item_id integer,
    target_level integer,
    vehicle_type_id integer,
    vehicle_nickname character varying(120),
    vehicle_wache_id integer,
    vehicle_wache_plan_item_id integer,
    wache_upgrade_id integer,
    extension_wache_id integer,
    extension_wache_plan_item_id integer
);


ALTER TABLE public.plan_item OWNER TO rescueop;

--
-- Name: plan_item_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.plan_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.plan_item_id_seq OWNER TO rescueop;

--
-- Name: plan_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.plan_item_id_seq OWNED BY public.plan_item.id;


--
-- Name: plan_item_modules; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.plan_item_modules (
    plan_item_id integer NOT NULL,
    vehicle_module_id integer NOT NULL
);


ALTER TABLE public.plan_item_modules OWNER TO rescueop;

--
-- Name: savegame; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.savegame (
    id integer NOT NULL,
    name character varying(120) NOT NULL,
    is_admin boolean NOT NULL,
    created_by_user_id integer,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.savegame OWNER TO rescueop;

--
-- Name: savegame_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.savegame_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.savegame_id_seq OWNER TO rescueop;

--
-- Name: savegame_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.savegame_id_seq OWNED BY public.savegame.id;


--
-- Name: savegame_membership; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.savegame_membership (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    user_id integer NOT NULL,
    role character varying(20) NOT NULL
);


ALTER TABLE public.savegame_membership OWNER TO rescueop;

--
-- Name: savegame_membership_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.savegame_membership_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.savegame_membership_id_seq OWNER TO rescueop;

--
-- Name: savegame_membership_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.savegame_membership_id_seq OWNED BY public.savegame_membership.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    username character varying(120) NOT NULL,
    password_hash character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public."user" OWNER TO rescueop;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_id_seq OWNER TO rescueop;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: vehicle_module; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.vehicle_module (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    name character varying(120) NOT NULL,
    price double precision NOT NULL
);


ALTER TABLE public.vehicle_module OWNER TO rescueop;

--
-- Name: vehicle_module_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.vehicle_module_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicle_module_id_seq OWNER TO rescueop;

--
-- Name: vehicle_module_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.vehicle_module_id_seq OWNED BY public.vehicle_module.id;


--
-- Name: vehicle_type; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.vehicle_type (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    name character varying(120) NOT NULL,
    abbreviation character varying(20),
    base_price double precision NOT NULL,
    maintenance_cost double precision NOT NULL,
    image character varying(255),
    is_standard boolean NOT NULL
);


ALTER TABLE public.vehicle_type OWNER TO rescueop;

--
-- Name: vehicle_type_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.vehicle_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.vehicle_type_id_seq OWNER TO rescueop;

--
-- Name: vehicle_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.vehicle_type_id_seq OWNED BY public.vehicle_type.id;


--
-- Name: vehicle_type_modules; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.vehicle_type_modules (
    vehicle_type_id integer NOT NULL,
    vehicle_module_id integer NOT NULL
);


ALTER TABLE public.vehicle_type_modules OWNER TO rescueop;

--
-- Name: vehicle_type_standard_modules; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.vehicle_type_standard_modules (
    vehicle_type_id integer NOT NULL,
    vehicle_module_id integer NOT NULL
);


ALTER TABLE public.vehicle_type_standard_modules OWNER TO rescueop;

--
-- Name: wache_level; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.wache_level (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    wache_type_id integer NOT NULL,
    level_number integer NOT NULL,
    name character varying(120),
    cost double precision NOT NULL,
    maintenance_cost double precision NOT NULL,
    max_vehicles integer NOT NULL
);


ALTER TABLE public.wache_level OWNER TO rescueop;

--
-- Name: wache_level_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.wache_level_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wache_level_id_seq OWNER TO rescueop;

--
-- Name: wache_level_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.wache_level_id_seq OWNED BY public.wache_level.id;


--
-- Name: wache_standard_vehicle; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.wache_standard_vehicle (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    wache_type_id integer NOT NULL,
    vehicle_type_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.wache_standard_vehicle OWNER TO rescueop;

--
-- Name: wache_standard_vehicle_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.wache_standard_vehicle_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wache_standard_vehicle_id_seq OWNER TO rescueop;

--
-- Name: wache_standard_vehicle_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.wache_standard_vehicle_id_seq OWNED BY public.wache_standard_vehicle.id;


--
-- Name: wache_standard_vehicle_item; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.wache_standard_vehicle_item (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    wache_type_id integer NOT NULL,
    vehicle_type_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.wache_standard_vehicle_item OWNER TO rescueop;

--
-- Name: wache_standard_vehicle_item_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.wache_standard_vehicle_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wache_standard_vehicle_item_id_seq OWNER TO rescueop;

--
-- Name: wache_standard_vehicle_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.wache_standard_vehicle_item_id_seq OWNED BY public.wache_standard_vehicle_item.id;


--
-- Name: wache_standard_vehicle_item_modules; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.wache_standard_vehicle_item_modules (
    wache_standard_vehicle_item_id integer NOT NULL,
    vehicle_module_id integer NOT NULL
);


ALTER TABLE public.wache_standard_vehicle_item_modules OWNER TO rescueop;

--
-- Name: wache_type; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.wache_type (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    name character varying(120) NOT NULL,
    image character varying(255)
);


ALTER TABLE public.wache_type OWNER TO rescueop;

--
-- Name: wache_type_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.wache_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wache_type_id_seq OWNER TO rescueop;

--
-- Name: wache_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.wache_type_id_seq OWNED BY public.wache_type.id;


--
-- Name: wache_upgrade; Type: TABLE; Schema: public; Owner: rescueop
--

CREATE TABLE public.wache_upgrade (
    id integer NOT NULL,
    savegame_id integer NOT NULL,
    wache_type_id integer NOT NULL,
    name character varying(120) NOT NULL,
    cost double precision NOT NULL,
    maintenance_cost double precision NOT NULL,
    extra_slots integer NOT NULL
);


ALTER TABLE public.wache_upgrade OWNER TO rescueop;

--
-- Name: wache_upgrade_id_seq; Type: SEQUENCE; Schema: public; Owner: rescueop
--

CREATE SEQUENCE public.wache_upgrade_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.wache_upgrade_id_seq OWNER TO rescueop;

--
-- Name: wache_upgrade_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: rescueop
--

ALTER SEQUENCE public.wache_upgrade_id_seq OWNED BY public.wache_upgrade.id;


--
-- Name: my_vehicle id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle ALTER COLUMN id SET DEFAULT nextval('public.my_vehicle_id_seq'::regclass);


--
-- Name: my_wache id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache ALTER COLUMN id SET DEFAULT nextval('public.my_wache_id_seq'::regclass);


--
-- Name: naming_location id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_location ALTER COLUMN id SET DEFAULT nextval('public.naming_location_id_seq'::regclass);


--
-- Name: naming_org_type id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_org_type ALTER COLUMN id SET DEFAULT nextval('public.naming_org_type_id_seq'::regclass);


--
-- Name: naming_preset id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_preset ALTER COLUMN id SET DEFAULT nextval('public.naming_preset_id_seq'::regclass);


--
-- Name: plan_item id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item ALTER COLUMN id SET DEFAULT nextval('public.plan_item_id_seq'::regclass);


--
-- Name: savegame id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame ALTER COLUMN id SET DEFAULT nextval('public.savegame_id_seq'::regclass);


--
-- Name: savegame_membership id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame_membership ALTER COLUMN id SET DEFAULT nextval('public.savegame_membership_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Name: vehicle_module id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_module ALTER COLUMN id SET DEFAULT nextval('public.vehicle_module_id_seq'::regclass);


--
-- Name: vehicle_type id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type ALTER COLUMN id SET DEFAULT nextval('public.vehicle_type_id_seq'::regclass);


--
-- Name: wache_level id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_level ALTER COLUMN id SET DEFAULT nextval('public.wache_level_id_seq'::regclass);


--
-- Name: wache_standard_vehicle id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle ALTER COLUMN id SET DEFAULT nextval('public.wache_standard_vehicle_id_seq'::regclass);


--
-- Name: wache_standard_vehicle_item id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item ALTER COLUMN id SET DEFAULT nextval('public.wache_standard_vehicle_item_id_seq'::regclass);


--
-- Name: wache_type id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_type ALTER COLUMN id SET DEFAULT nextval('public.wache_type_id_seq'::regclass);


--
-- Name: wache_upgrade id; Type: DEFAULT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_upgrade ALTER COLUMN id SET DEFAULT nextval('public.wache_upgrade_id_seq'::regclass);


--
-- Data for Name: my_vehicle; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.my_vehicle (id, savegame_id, my_wache_id, vehicle_type_id, nickname) FROM stdin;
\.


--
-- Data for Name: my_vehicle_modules; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.my_vehicle_modules (my_vehicle_id, vehicle_module_id) FROM stdin;
\.


--
-- Data for Name: my_wache; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.my_wache (id, savegame_id, name, wache_type_id, current_level, naming_org_type_id, naming_location_id) FROM stdin;
\.


--
-- Data for Name: my_wache_upgrades; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.my_wache_upgrades (my_wache_id, wache_upgrade_id) FROM stdin;
\.


--
-- Data for Name: naming_location; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.naming_location (id, savegame_id, abbreviation, full_name) FROM stdin;
\.


--
-- Data for Name: naming_org_type; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.naming_org_type (id, savegame_id, abbreviation, full_name, no_location, default_wache_type_id) FROM stdin;
\.


--
-- Data for Name: naming_preset; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.naming_preset (id, savegame_id, name, template, description, is_default) FROM stdin;
\.


--
-- Data for Name: plan_item; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.plan_item (id, savegame_id, category, priority, done, notes, wache_name, wache_type_id, wache_org_type_id, wache_location_id, created_wache_id, target_wache_id, target_wache_plan_item_id, target_level, vehicle_type_id, vehicle_nickname, vehicle_wache_id, vehicle_wache_plan_item_id, wache_upgrade_id, extension_wache_id, extension_wache_plan_item_id) FROM stdin;
\.


--
-- Data for Name: plan_item_modules; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.plan_item_modules (plan_item_id, vehicle_module_id) FROM stdin;
\.


--
-- Data for Name: savegame; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.savegame (id, name, is_admin, created_by_user_id, created_at) FROM stdin;
1	Admin	t	1	2026-09-09 08:03:09.785697
\.


--
-- Data for Name: savegame_membership; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.savegame_membership (id, savegame_id, user_id, role) FROM stdin;
1	1	1	owner
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public."user" (id, username, password_hash, created_at) FROM stdin;
1	admin	scrypt:32768:8:1$Un7DeGGJZKXmOXjO$a8f9124597adeabb0007b529b364d7e77881ea917e4594928edbec2a6e7b26c87fcb8a4c9a08b711899046ee15771365c250cba5d3b4eb515c5961e31c1ea2e5	2026-09-09 08:03:09.785697
\.


--
-- Data for Name: vehicle_module; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.vehicle_module (id, savegame_id, name, price) FROM stdin;
\.


--
-- Data for Name: vehicle_type; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.vehicle_type (id, savegame_id, name, abbreviation, base_price, maintenance_cost, image, is_standard) FROM stdin;
\.


--
-- Data for Name: vehicle_type_modules; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.vehicle_type_modules (vehicle_type_id, vehicle_module_id) FROM stdin;
\.


--
-- Data for Name: vehicle_type_standard_modules; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.vehicle_type_standard_modules (vehicle_type_id, vehicle_module_id) FROM stdin;
\.


--
-- Data for Name: wache_level; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.wache_level (id, savegame_id, wache_type_id, level_number, name, cost, maintenance_cost, max_vehicles) FROM stdin;
\.


--
-- Data for Name: wache_standard_vehicle; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.wache_standard_vehicle (id, savegame_id, wache_type_id, vehicle_type_id, quantity) FROM stdin;
\.


--
-- Data for Name: wache_standard_vehicle_item; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.wache_standard_vehicle_item (id, savegame_id, wache_type_id, vehicle_type_id, quantity) FROM stdin;
\.


--
-- Data for Name: wache_standard_vehicle_item_modules; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.wache_standard_vehicle_item_modules (wache_standard_vehicle_item_id, vehicle_module_id) FROM stdin;
\.


--
-- Data for Name: wache_type; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.wache_type (id, savegame_id, name, image) FROM stdin;
\.


--
-- Data for Name: wache_upgrade; Type: TABLE DATA; Schema: public; Owner: rescueop
--

COPY public.wache_upgrade (id, savegame_id, wache_type_id, name, cost, maintenance_cost, extra_slots) FROM stdin;
\.


--
-- Name: my_vehicle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.my_vehicle_id_seq', 1, false);


--
-- Name: my_wache_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.my_wache_id_seq', 1, false);


--
-- Name: naming_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.naming_location_id_seq', 1, false);


--
-- Name: naming_org_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.naming_org_type_id_seq', 1, false);


--
-- Name: naming_preset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.naming_preset_id_seq', 1, false);


--
-- Name: plan_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.plan_item_id_seq', 1, false);


--
-- Name: savegame_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.savegame_id_seq', 1, true);


--
-- Name: savegame_membership_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.savegame_membership_id_seq', 1, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.user_id_seq', 1, true);


--
-- Name: vehicle_module_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.vehicle_module_id_seq', 1, false);


--
-- Name: vehicle_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.vehicle_type_id_seq', 1, false);


--
-- Name: wache_level_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.wache_level_id_seq', 1, false);


--
-- Name: wache_standard_vehicle_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.wache_standard_vehicle_id_seq', 1, false);


--
-- Name: wache_standard_vehicle_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.wache_standard_vehicle_item_id_seq', 1, false);


--
-- Name: wache_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.wache_type_id_seq', 1, false);


--
-- Name: wache_upgrade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: rescueop
--

SELECT pg_catalog.setval('public.wache_upgrade_id_seq', 1, false);


--
-- Name: my_vehicle_modules my_vehicle_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle_modules
    ADD CONSTRAINT my_vehicle_modules_pkey PRIMARY KEY (my_vehicle_id, vehicle_module_id);


--
-- Name: my_vehicle my_vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle
    ADD CONSTRAINT my_vehicle_pkey PRIMARY KEY (id);


--
-- Name: my_wache my_wache_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache
    ADD CONSTRAINT my_wache_pkey PRIMARY KEY (id);


--
-- Name: my_wache_upgrades my_wache_upgrades_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache_upgrades
    ADD CONSTRAINT my_wache_upgrades_pkey PRIMARY KEY (my_wache_id, wache_upgrade_id);


--
-- Name: naming_location naming_location_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_location
    ADD CONSTRAINT naming_location_pkey PRIMARY KEY (id);


--
-- Name: naming_org_type naming_org_type_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_org_type
    ADD CONSTRAINT naming_org_type_pkey PRIMARY KEY (id);


--
-- Name: naming_preset naming_preset_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_preset
    ADD CONSTRAINT naming_preset_pkey PRIMARY KEY (id);


--
-- Name: plan_item_modules plan_item_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item_modules
    ADD CONSTRAINT plan_item_modules_pkey PRIMARY KEY (plan_item_id, vehicle_module_id);


--
-- Name: plan_item plan_item_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_pkey PRIMARY KEY (id);


--
-- Name: savegame_membership savegame_membership_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame_membership
    ADD CONSTRAINT savegame_membership_pkey PRIMARY KEY (id);


--
-- Name: savegame savegame_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame
    ADD CONSTRAINT savegame_pkey PRIMARY KEY (id);


--
-- Name: naming_location uq_location_abbr_per_savegame; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_location
    ADD CONSTRAINT uq_location_abbr_per_savegame UNIQUE (savegame_id, abbreviation);


--
-- Name: naming_preset uq_naming_preset_name_per_savegame; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_preset
    ADD CONSTRAINT uq_naming_preset_name_per_savegame UNIQUE (savegame_id, name);


--
-- Name: naming_org_type uq_org_abbr_per_savegame; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_org_type
    ADD CONSTRAINT uq_org_abbr_per_savegame UNIQUE (savegame_id, abbreviation);


--
-- Name: savegame_membership uq_savegame_user; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame_membership
    ADD CONSTRAINT uq_savegame_user UNIQUE (savegame_id, user_id);


--
-- Name: wache_standard_vehicle uq_wache_std_vehicle_per_type; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle
    ADD CONSTRAINT uq_wache_std_vehicle_per_type UNIQUE (savegame_id, wache_type_id, vehicle_type_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user user_username_key; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


--
-- Name: vehicle_module vehicle_module_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_module
    ADD CONSTRAINT vehicle_module_pkey PRIMARY KEY (id);


--
-- Name: vehicle_type_modules vehicle_type_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type_modules
    ADD CONSTRAINT vehicle_type_modules_pkey PRIMARY KEY (vehicle_type_id, vehicle_module_id);


--
-- Name: vehicle_type vehicle_type_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type
    ADD CONSTRAINT vehicle_type_pkey PRIMARY KEY (id);


--
-- Name: vehicle_type_standard_modules vehicle_type_standard_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type_standard_modules
    ADD CONSTRAINT vehicle_type_standard_modules_pkey PRIMARY KEY (vehicle_type_id, vehicle_module_id);


--
-- Name: wache_level wache_level_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_level
    ADD CONSTRAINT wache_level_pkey PRIMARY KEY (id);


--
-- Name: wache_standard_vehicle_item_modules wache_standard_vehicle_item_modules_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item_modules
    ADD CONSTRAINT wache_standard_vehicle_item_modules_pkey PRIMARY KEY (wache_standard_vehicle_item_id, vehicle_module_id);


--
-- Name: wache_standard_vehicle_item wache_standard_vehicle_item_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item
    ADD CONSTRAINT wache_standard_vehicle_item_pkey PRIMARY KEY (id);


--
-- Name: wache_standard_vehicle wache_standard_vehicle_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle
    ADD CONSTRAINT wache_standard_vehicle_pkey PRIMARY KEY (id);


--
-- Name: wache_type wache_type_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_type
    ADD CONSTRAINT wache_type_pkey PRIMARY KEY (id);


--
-- Name: wache_upgrade wache_upgrade_pkey; Type: CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_upgrade
    ADD CONSTRAINT wache_upgrade_pkey PRIMARY KEY (id);


--
-- Name: ix_my_vehicle_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_my_vehicle_savegame_id ON public.my_vehicle USING btree (savegame_id);


--
-- Name: ix_my_vehicle_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_my_vehicle_type_id ON public.my_vehicle USING btree (vehicle_type_id);


--
-- Name: ix_my_vehicle_wache_type; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_my_vehicle_wache_type ON public.my_vehicle USING btree (my_wache_id, vehicle_type_id);


--
-- Name: ix_my_wache_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_my_wache_savegame_id ON public.my_wache USING btree (savegame_id);


--
-- Name: ix_my_wache_savegame_name; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_my_wache_savegame_name ON public.my_wache USING btree (savegame_id, name);


--
-- Name: ix_my_wache_wache_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_my_wache_wache_type_id ON public.my_wache USING btree (wache_type_id);


--
-- Name: ix_naming_location_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_naming_location_savegame_id ON public.naming_location USING btree (savegame_id);


--
-- Name: ix_naming_org_type_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_naming_org_type_savegame_id ON public.naming_org_type USING btree (savegame_id);


--
-- Name: ix_naming_preset_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_naming_preset_savegame_id ON public.naming_preset USING btree (savegame_id);


--
-- Name: ix_plan_item_extension_wache_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_plan_item_extension_wache_id ON public.plan_item USING btree (extension_wache_id);


--
-- Name: ix_plan_item_savegame_done_priority; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_plan_item_savegame_done_priority ON public.plan_item USING btree (savegame_id, done, priority);


--
-- Name: ix_plan_item_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_plan_item_savegame_id ON public.plan_item USING btree (savegame_id);


--
-- Name: ix_plan_item_target_wache_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_plan_item_target_wache_id ON public.plan_item USING btree (target_wache_id);


--
-- Name: ix_plan_item_vehicle_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_plan_item_vehicle_type_id ON public.plan_item USING btree (vehicle_type_id);


--
-- Name: ix_plan_item_vehicle_wache_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_plan_item_vehicle_wache_id ON public.plan_item USING btree (vehicle_wache_id);


--
-- Name: ix_savegame_membership_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_savegame_membership_savegame_id ON public.savegame_membership USING btree (savegame_id);


--
-- Name: ix_savegame_membership_user_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_savegame_membership_user_id ON public.savegame_membership USING btree (user_id);


--
-- Name: ix_vehicle_module_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_vehicle_module_savegame_id ON public.vehicle_module USING btree (savegame_id);


--
-- Name: ix_vehicle_type_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_vehicle_type_savegame_id ON public.vehicle_type USING btree (savegame_id);


--
-- Name: ix_wache_level_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_level_savegame_id ON public.wache_level USING btree (savegame_id);


--
-- Name: ix_wache_level_wache_type_level; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_level_wache_type_level ON public.wache_level USING btree (wache_type_id, level_number);


--
-- Name: ix_wache_standard_vehicle_item_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_standard_vehicle_item_savegame_id ON public.wache_standard_vehicle_item USING btree (savegame_id);


--
-- Name: ix_wache_standard_vehicle_item_vehicle_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_standard_vehicle_item_vehicle_type_id ON public.wache_standard_vehicle_item USING btree (vehicle_type_id);


--
-- Name: ix_wache_standard_vehicle_item_wache_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_standard_vehicle_item_wache_type_id ON public.wache_standard_vehicle_item USING btree (wache_type_id);


--
-- Name: ix_wache_standard_vehicle_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_standard_vehicle_savegame_id ON public.wache_standard_vehicle USING btree (savegame_id);


--
-- Name: ix_wache_standard_vehicle_vehicle_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_standard_vehicle_vehicle_type_id ON public.wache_standard_vehicle USING btree (vehicle_type_id);


--
-- Name: ix_wache_standard_vehicle_wache_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_standard_vehicle_wache_type_id ON public.wache_standard_vehicle USING btree (wache_type_id);


--
-- Name: ix_wache_type_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_type_savegame_id ON public.wache_type USING btree (savegame_id);


--
-- Name: ix_wache_upgrade_savegame_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_upgrade_savegame_id ON public.wache_upgrade USING btree (savegame_id);


--
-- Name: ix_wache_upgrade_wache_type_id; Type: INDEX; Schema: public; Owner: rescueop
--

CREATE INDEX ix_wache_upgrade_wache_type_id ON public.wache_upgrade USING btree (wache_type_id);


--
-- Name: my_vehicle_modules my_vehicle_modules_my_vehicle_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle_modules
    ADD CONSTRAINT my_vehicle_modules_my_vehicle_id_fkey FOREIGN KEY (my_vehicle_id) REFERENCES public.my_vehicle(id);


--
-- Name: my_vehicle_modules my_vehicle_modules_vehicle_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle_modules
    ADD CONSTRAINT my_vehicle_modules_vehicle_module_id_fkey FOREIGN KEY (vehicle_module_id) REFERENCES public.vehicle_module(id);


--
-- Name: my_vehicle my_vehicle_my_wache_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle
    ADD CONSTRAINT my_vehicle_my_wache_id_fkey FOREIGN KEY (my_wache_id) REFERENCES public.my_wache(id);


--
-- Name: my_vehicle my_vehicle_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle
    ADD CONSTRAINT my_vehicle_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: my_vehicle my_vehicle_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_vehicle
    ADD CONSTRAINT my_vehicle_vehicle_type_id_fkey FOREIGN KEY (vehicle_type_id) REFERENCES public.vehicle_type(id);


--
-- Name: my_wache my_wache_naming_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache
    ADD CONSTRAINT my_wache_naming_location_id_fkey FOREIGN KEY (naming_location_id) REFERENCES public.naming_location(id);


--
-- Name: my_wache my_wache_naming_org_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache
    ADD CONSTRAINT my_wache_naming_org_type_id_fkey FOREIGN KEY (naming_org_type_id) REFERENCES public.naming_org_type(id);


--
-- Name: my_wache my_wache_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache
    ADD CONSTRAINT my_wache_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: my_wache_upgrades my_wache_upgrades_my_wache_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache_upgrades
    ADD CONSTRAINT my_wache_upgrades_my_wache_id_fkey FOREIGN KEY (my_wache_id) REFERENCES public.my_wache(id);


--
-- Name: my_wache_upgrades my_wache_upgrades_wache_upgrade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache_upgrades
    ADD CONSTRAINT my_wache_upgrades_wache_upgrade_id_fkey FOREIGN KEY (wache_upgrade_id) REFERENCES public.wache_upgrade(id);


--
-- Name: my_wache my_wache_wache_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.my_wache
    ADD CONSTRAINT my_wache_wache_type_id_fkey FOREIGN KEY (wache_type_id) REFERENCES public.wache_type(id);


--
-- Name: naming_location naming_location_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_location
    ADD CONSTRAINT naming_location_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: naming_org_type naming_org_type_default_wache_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_org_type
    ADD CONSTRAINT naming_org_type_default_wache_type_id_fkey FOREIGN KEY (default_wache_type_id) REFERENCES public.wache_type(id);


--
-- Name: naming_org_type naming_org_type_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_org_type
    ADD CONSTRAINT naming_org_type_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: naming_preset naming_preset_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.naming_preset
    ADD CONSTRAINT naming_preset_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: plan_item plan_item_created_wache_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_created_wache_id_fkey FOREIGN KEY (created_wache_id) REFERENCES public.my_wache(id);


--
-- Name: plan_item plan_item_extension_wache_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_extension_wache_id_fkey FOREIGN KEY (extension_wache_id) REFERENCES public.my_wache(id);


--
-- Name: plan_item plan_item_extension_wache_plan_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_extension_wache_plan_item_id_fkey FOREIGN KEY (extension_wache_plan_item_id) REFERENCES public.plan_item(id);


--
-- Name: plan_item_modules plan_item_modules_plan_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item_modules
    ADD CONSTRAINT plan_item_modules_plan_item_id_fkey FOREIGN KEY (plan_item_id) REFERENCES public.plan_item(id);


--
-- Name: plan_item_modules plan_item_modules_vehicle_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item_modules
    ADD CONSTRAINT plan_item_modules_vehicle_module_id_fkey FOREIGN KEY (vehicle_module_id) REFERENCES public.vehicle_module(id);


--
-- Name: plan_item plan_item_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: plan_item plan_item_target_wache_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_target_wache_id_fkey FOREIGN KEY (target_wache_id) REFERENCES public.my_wache(id);


--
-- Name: plan_item plan_item_target_wache_plan_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_target_wache_plan_item_id_fkey FOREIGN KEY (target_wache_plan_item_id) REFERENCES public.plan_item(id);


--
-- Name: plan_item plan_item_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_vehicle_type_id_fkey FOREIGN KEY (vehicle_type_id) REFERENCES public.vehicle_type(id);


--
-- Name: plan_item plan_item_vehicle_wache_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_vehicle_wache_id_fkey FOREIGN KEY (vehicle_wache_id) REFERENCES public.my_wache(id);


--
-- Name: plan_item plan_item_vehicle_wache_plan_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_vehicle_wache_plan_item_id_fkey FOREIGN KEY (vehicle_wache_plan_item_id) REFERENCES public.plan_item(id);


--
-- Name: plan_item plan_item_wache_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_wache_location_id_fkey FOREIGN KEY (wache_location_id) REFERENCES public.naming_location(id);


--
-- Name: plan_item plan_item_wache_org_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_wache_org_type_id_fkey FOREIGN KEY (wache_org_type_id) REFERENCES public.naming_org_type(id);


--
-- Name: plan_item plan_item_wache_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_wache_type_id_fkey FOREIGN KEY (wache_type_id) REFERENCES public.wache_type(id);


--
-- Name: plan_item plan_item_wache_upgrade_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.plan_item
    ADD CONSTRAINT plan_item_wache_upgrade_id_fkey FOREIGN KEY (wache_upgrade_id) REFERENCES public.wache_upgrade(id);


--
-- Name: savegame savegame_created_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame
    ADD CONSTRAINT savegame_created_by_user_id_fkey FOREIGN KEY (created_by_user_id) REFERENCES public."user"(id);


--
-- Name: savegame_membership savegame_membership_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame_membership
    ADD CONSTRAINT savegame_membership_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: savegame_membership savegame_membership_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.savegame_membership
    ADD CONSTRAINT savegame_membership_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: vehicle_module vehicle_module_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_module
    ADD CONSTRAINT vehicle_module_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: vehicle_type_modules vehicle_type_modules_vehicle_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type_modules
    ADD CONSTRAINT vehicle_type_modules_vehicle_module_id_fkey FOREIGN KEY (vehicle_module_id) REFERENCES public.vehicle_module(id);


--
-- Name: vehicle_type_modules vehicle_type_modules_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type_modules
    ADD CONSTRAINT vehicle_type_modules_vehicle_type_id_fkey FOREIGN KEY (vehicle_type_id) REFERENCES public.vehicle_type(id);


--
-- Name: vehicle_type vehicle_type_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type
    ADD CONSTRAINT vehicle_type_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: vehicle_type_standard_modules vehicle_type_standard_modules_vehicle_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type_standard_modules
    ADD CONSTRAINT vehicle_type_standard_modules_vehicle_module_id_fkey FOREIGN KEY (vehicle_module_id) REFERENCES public.vehicle_module(id);


--
-- Name: vehicle_type_standard_modules vehicle_type_standard_modules_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.vehicle_type_standard_modules
    ADD CONSTRAINT vehicle_type_standard_modules_vehicle_type_id_fkey FOREIGN KEY (vehicle_type_id) REFERENCES public.vehicle_type(id);


--
-- Name: wache_level wache_level_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_level
    ADD CONSTRAINT wache_level_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: wache_level wache_level_wache_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_level
    ADD CONSTRAINT wache_level_wache_type_id_fkey FOREIGN KEY (wache_type_id) REFERENCES public.wache_type(id);


--
-- Name: wache_standard_vehicle_item_modules wache_standard_vehicle_item_m_wache_standard_vehicle_item__fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item_modules
    ADD CONSTRAINT wache_standard_vehicle_item_m_wache_standard_vehicle_item__fkey FOREIGN KEY (wache_standard_vehicle_item_id) REFERENCES public.wache_standard_vehicle_item(id);


--
-- Name: wache_standard_vehicle_item_modules wache_standard_vehicle_item_modules_vehicle_module_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item_modules
    ADD CONSTRAINT wache_standard_vehicle_item_modules_vehicle_module_id_fkey FOREIGN KEY (vehicle_module_id) REFERENCES public.vehicle_module(id);


--
-- Name: wache_standard_vehicle_item wache_standard_vehicle_item_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item
    ADD CONSTRAINT wache_standard_vehicle_item_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: wache_standard_vehicle_item wache_standard_vehicle_item_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item
    ADD CONSTRAINT wache_standard_vehicle_item_vehicle_type_id_fkey FOREIGN KEY (vehicle_type_id) REFERENCES public.vehicle_type(id);


--
-- Name: wache_standard_vehicle_item wache_standard_vehicle_item_wache_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle_item
    ADD CONSTRAINT wache_standard_vehicle_item_wache_type_id_fkey FOREIGN KEY (wache_type_id) REFERENCES public.wache_type(id);


--
-- Name: wache_standard_vehicle wache_standard_vehicle_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle
    ADD CONSTRAINT wache_standard_vehicle_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: wache_standard_vehicle wache_standard_vehicle_vehicle_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle
    ADD CONSTRAINT wache_standard_vehicle_vehicle_type_id_fkey FOREIGN KEY (vehicle_type_id) REFERENCES public.vehicle_type(id);


--
-- Name: wache_standard_vehicle wache_standard_vehicle_wache_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_standard_vehicle
    ADD CONSTRAINT wache_standard_vehicle_wache_type_id_fkey FOREIGN KEY (wache_type_id) REFERENCES public.wache_type(id);


--
-- Name: wache_type wache_type_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_type
    ADD CONSTRAINT wache_type_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: wache_upgrade wache_upgrade_savegame_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_upgrade
    ADD CONSTRAINT wache_upgrade_savegame_id_fkey FOREIGN KEY (savegame_id) REFERENCES public.savegame(id);


--
-- Name: wache_upgrade wache_upgrade_wache_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: rescueop
--

ALTER TABLE ONLY public.wache_upgrade
    ADD CONSTRAINT wache_upgrade_wache_type_id_fkey FOREIGN KEY (wache_type_id) REFERENCES public.wache_type(id);


--
-- PostgreSQL database dump complete
--

\unrestrict FrpdeujimlSi6fU2iSVqsQFqI8kNI56hVOXYmHzfE9VrSE6uqCFNoUvWdde94m3

